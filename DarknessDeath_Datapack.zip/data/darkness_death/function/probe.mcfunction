# /function darkness_death:probe -> muestra UN frame fijo (corazon dorado) a todos, sin sonido
title @a times 0 40 0
title @a title [{"text":"\ue130","font":"darkness_death:anim","color":"white","shadow_color":0},{"text":"\uf801","font":"darkness_death:anim","shadow_color":0},{"text":"\ue131","font":"darkness_death:anim","color":"white","shadow_color":0},{"text":"\uf801","font":"darkness_death:anim","shadow_color":0}]
