# Inicializa marcadores de jugadores nuevos (-1 = inactivo)
execute as @a unless score @s dd_wait = @s dd_wait run scoreboard players set @s dd_wait -1
execute as @a unless score @s dd_t = @s dd_t run scoreboard players set @s dd_t -1
execute as @a[scores={dd_deaths=1..}] run function darkness_death:on_death
execute as @a[scores={dd_wait=0..}] run function darkness_death:wait_respawn
execute as @a[scores={dd_t=0..}] run function darkness_death:step
