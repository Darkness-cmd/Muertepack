# /function darkness_death:test  -> prueba la animacion y los sonidos sin morir
function darkness_death:start
