title @s clear
title @s reset
scoreboard players set @s dd_t -1
